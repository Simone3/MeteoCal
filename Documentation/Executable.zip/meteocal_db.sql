-- User and database
CREATE SCHEMA IF NOT EXISTS `meteocal` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
GRANT INSERT, DELETE, UPDATE, SELECT ON meteocal.* TO 'admin'@'localhost' IDENTIFIED BY 'admin';
flush PRIVILEGES;
USE `meteocal` ;
---------------------------------------------------------------------------------------


-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';


-- -----------------------------------------------------
-- Table `meteocal`.`Usertable`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `meteocal`.`Usertable` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `firstName` VARCHAR(75) NOT NULL,
  `lastName` VARCHAR(75) NOT NULL,
  `email` VARCHAR(75) NOT NULL,
  `password` VARCHAR(100) NOT NULL,
  `userGroup` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `email_UNIQUE` (`email` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `meteocal`.`Calendar`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `meteocal`.`Calendar` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `ownerId` INT NOT NULL,
  `rainIsBad` TINYINT(1) NOT NULL,
  `cloudyIsBad` TINYINT(1) NOT NULL,
  `snowIsBad` TINYINT(1) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Calendar_User_idx` (`ownerId` ASC),
  CONSTRAINT `fk_Calendar_User`
    FOREIGN KEY (`ownerId`)
    REFERENCES `meteocal`.`Usertable` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `meteocal`.`Event`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `meteocal`.`Event` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(75) NOT NULL,
  `city` VARCHAR(75) NOT NULL,
  `locationDetails` VARCHAR(100) NULL,
  `outdoor` TINYINT(1) NOT NULL,
  `eventDay` DATE NOT NULL,
  `startTime` TIME NOT NULL,
  `endTime` TIME NOT NULL,
  `weatherForecast` VARCHAR(200) NULL,
  `organizerId` INT NOT NULL,
  `badWeatherAlertSent` TINYINT(1) NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Event_User1_idx` (`organizerId` ASC),
  CONSTRAINT `fk_Event_User1`
    FOREIGN KEY (`organizerId`)
    REFERENCES `meteocal`.`Usertable` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `meteocal`.`Calendar_has_Events`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `meteocal`.`Calendar_has_Events` (
  `calendarId` INT NOT NULL,
  `eventId` INT NOT NULL,
  PRIMARY KEY (`calendarId`, `eventId`),
  INDEX `fk_Calendar_has_Event_Event1_idx` (`eventId` ASC),
  INDEX `fk_Calendar_has_Event_Calendar1_idx` (`calendarId` ASC),
  CONSTRAINT `fk_Calendar_has_Event_Calendar1`
    FOREIGN KEY (`calendarId`)
    REFERENCES `meteocal`.`Calendar` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Calendar_has_Event_Event1`
    FOREIGN KEY (`eventId`)
    REFERENCES `meteocal`.`Event` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `meteocal`.`Notification`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `meteocal`.`Notification` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(200) NOT NULL,
  `content` LONGTEXT NOT NULL,
  `sendDate` DATETIME NOT NULL,
  `invitation` TINYINT(1) NOT NULL,
  `isRead` TINYINT(1) NOT NULL,
  `eventId` INT NOT NULL,
  `receiverId` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Notification_Event1_idx` (`eventId` ASC),
  INDEX `fk_Notification_User1_idx` (`receiverId` ASC),
  CONSTRAINT `fk_Notification_Event1`
    FOREIGN KEY (`eventId`)
    REFERENCES `meteocal`.`Event` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Notification_User1`
    FOREIGN KEY (`receiverId`)
    REFERENCES `meteocal`.`Usertable` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
